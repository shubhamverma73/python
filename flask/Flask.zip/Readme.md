source ./venv/Scripts/activate


flask run

python app.py