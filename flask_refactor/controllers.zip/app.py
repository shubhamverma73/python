from flask import Flask
from flask_cors import CORS

from config import Config
from extensions import db, bcrypt, jwt

from routes import register_routes
from middleware.error_handler import register_error_handlers

from utils.logger import setup_logger
import logging

from routes.auth_routes import auth_bp

setup_logger()
logger = logging.getLogger(__name__)
logger.info("Flask application started.")

def create_app():

    app = Flask(__name__)

    app.config.from_object(Config)

    app.register_blueprint(auth_bp)

    CORS(app)

    db.init_app(app)
    bcrypt.init_app(app)
    jwt.init_app(app)

    register_routes(app)

    register_error_handlers(app)

    with app.app_context():
        db.create_all()

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
